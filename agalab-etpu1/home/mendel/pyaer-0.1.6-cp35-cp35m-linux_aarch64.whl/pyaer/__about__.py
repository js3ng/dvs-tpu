"""About page."""
from __future__ import print_function, absolute_import

__all__ = [
    "__version__", "__author__", "__author_email__",
    "__url__"]

__version__ = "0.1.6"
__author__ = "Yuhuang Hu"
__author_email__ = "duguyue100@gmail.com"
__url__ = "https://github.com/duguyue100/pyaer"
